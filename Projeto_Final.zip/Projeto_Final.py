import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter.messagebox as messagebox
import numpy as np

# Lista para armazenar as coordenadas dos pontos
coordenadas = []
numero_ponto = 1

# Lista para armazenar as barras (arestas)
barras = []

# Lista para armazenar os apoios
apoios = []

# Lista para armazenar as forças
forcas = []

# Variável para armazenar o limite
limite = None

# Função para verificar se duas barras se cruzam
def verificar_intersecao(barra1, barra2):
    p1x, p1y = coordenadas[barra1[0] - 1][:2]
    p2x, p2y = coordenadas[barra1[1] - 1][:2]
    p3x, p3y = coordenadas[barra2[0] - 1][:2]
    p4x, p4y = coordenadas[barra2[1] - 1][:2]

    # Teste de interseção utilizando o método das áreas
    d1 = (p4x - p3x) * (p1y - p3y) - (p4y - p3y) * (p1x - p3x)
    d2 = (p4x - p3x) * (p2y - p3y) - (p4y - p3y) * (p2x - p3x)
    d3 = (p2x - p1x) * (p3y - p1y) - (p2y - p1y) * (p3x - p1x)
    d4 = (p2x - p1x) * (p4y - p1y) - (p2y - p1y) * (p4x - p1x)

    if d1 * d2 < 0 and d3 * d4 < 0:
        return True
    else:
        return False

# Função para adicionar as coordenadas quando o botão "Adicionar Ponto" for clicado
def adicionar_ponto():
    global numero_ponto
    x = float(entry_x.get())
    y = float(entry_y.get())
    coordenadas.append((x, y, numero_ponto))
    numero_ponto += 1

    # Limpar as entradas de texto
    entry_x.delete(0, tk.END)
    entry_y.delete(0, tk.END)

    # Atualizar o gráfico
    atualizar_grafico()

# Função para adicionar uma barra (aresta) entre dois pontos
def adicionar_barra():
    ponto1 = int(entry_ponto1.get())
    ponto2 = int(entry_ponto2.get())

    if ponto1 > 0 and ponto1 <= len(coordenadas) and ponto2 > 0 and ponto2 <= len(coordenadas) and ponto1 != ponto2:
        nova_barra = (ponto1, ponto2)

        # Verificar interseção com as barras existentes
        for barra in barras:
            if verificar_intersecao(nova_barra, barra):
                messagebox.showerror("Erro", "As barras se cruzam!")
                return

        barras.append(nova_barra)

        # Limpar as entradas de texto
        entry_ponto1.delete(0, tk.END)
        entry_ponto2.delete(0, tk.END)

        # Atualizar o gráfico
        atualizar_grafico()

# Função para adicionar um apoio fixo
def adicionar_apoio():
    ponto = int(entry_apoio.get())
    tipo = combo_tipo_apoio.get()

    if ponto > 0 and ponto <= len(coordenadas):
        apoios.append((ponto, tipo))

        # Limpar a entrada de texto
        entry_apoio.delete(0, tk.END)

        # Atualizar o gráfico
        atualizar_grafico()

# Função para adicionar uma força externa
def adicionar_forca():
    ponto = int(entry_forca.get())
    intensidade = float(entry_intensidade.get())
    eixo = combo_eixo.get()
    sentido = combo_sentido.get()

    if ponto > 0 and ponto <= len(coordenadas):
        forcas.append((ponto, intensidade, eixo, sentido))

        # Limpar as entradas de texto
        entry_forca.delete(0, tk.END)
        entry_intensidade.delete(0, tk.END)

        # Atualizar o gráfico
        atualizar_grafico()

# Função para atualizar o gráfico
def atualizar_grafico():
    plt.clf()  # Limpar o gráfico

    # Plotar os pontos
    pontos_x = [coord[0] for coord in coordenadas]
    pontos_y = [coord[1] for coord in coordenadas]
    numeros = [coord[2] for coord in coordenadas]

    for x, y, num in zip(pontos_x, pontos_y, numeros):
        plt.text(x, y, str(num), color='blue', fontsize=12, ha='center', va='center')

    plt.plot(pontos_x, pontos_y, 'ro')

    # Plotar as barras
    for barra in barras:
        ponto1 = coordenadas[barra[0] - 1]
        ponto2 = coordenadas[barra[1] - 1]
        plt.plot([ponto1[0], ponto2[0]], [ponto1[1], ponto2[1]], 'b-')

    # Plotar os apoios
    for apoio in apoios:
        ponto = coordenadas[apoio[0] - 1]
        tipo = apoio[1]
        if tipo == 'Fixo x':
            plt.plot([ponto[0], ponto[0]], [ponto[1] - 0.5, ponto[1] + 0.5], 'g-')
            plt.plot(ponto[0], ponto[1], 'g^')
        elif tipo == 'Fixo y':
            plt.plot([ponto[0] - 0.5, ponto[0] + 0.5], [ponto[1], ponto[1]], 'g-')
            plt.plot(ponto[0], ponto[1], 'g^')
        elif tipo == 'Fixo':
            plt.plot([ponto[0] - 0.5, ponto[0] + 0.5], [ponto[1] - 0.5, ponto[1] + 0.5], 'g-')
            plt.plot(ponto[0], ponto[1], 'g^')

    # Plotar as forças
    for forca in forcas:
        ponto = coordenadas[forca[0] - 1]
        intensidade = forca[1]
        eixo = forca[2]
        sentido = forca[3]
        if eixo == 'x':
            if sentido == 'positivo':
                plt.arrow(ponto[0], ponto[1], 0.5, 0, head_width=0.2, head_length=0.3, fc='r', ec='r')
            elif sentido == 'negativo':
                plt.arrow(ponto[0], ponto[1], -0.5, 0, head_width=0.2, head_length=0.3, fc='r', ec='r')
        elif eixo == 'y':
            if sentido == 'positivo':
                plt.arrow(ponto[0], ponto[1], 0, 0.5, head_width=0.2, head_length=0.3, fc='r', ec='r')
            elif sentido == 'negativo':
                plt.arrow(ponto[0], ponto[1], 0, -0.5, head_width=0.2, head_length=0.3, fc='r', ec='r')

    # Configurar os limites do gráfico
    if limite:
        plt.xlim(limite[0], limite[1])
        plt.ylim(limite[2], limite[3])

    canvas.draw()

# Função para calcular as forças de reação e os esforços nas barras
def calcular_forcas():
    if len(coordenadas) == 0 or len(barras) == 0 or len(apoios) == 0 or len(forcas) == 0:
        messagebox.showerror("Erro", "Insira todas as informações necessárias.")
        return

    # Montagem da matriz de rigidez global
    num_graus_liberdade = 2 * len(coordenadas)
    K = np.zeros((num_graus_liberdade, num_graus_liberdade))

    for barra in barras:
        n1, n2 = barra
        x1, y1 = coordenadas[n1 - 1][:2]
        x2, y2 = coordenadas[n2 - 1][:2]

        LX = x2 - x1
        LY = y2 - y1
        L = np.sqrt(LX ** 2 + LY ** 2)
        seno = LY / L
        coss = LX / L

        gl1 = 2 * n1 - 1
        gl2 = 2 * n1
        gl3 = 2 * n2 - 1
        gl4 = 2 * n2

        Kl = np.array([[1, 0, -1, 0],
                       [0, 0, 0, 0],
                       [-1, 0, 1, 0],
                       [0, 0, 0, 0]])

        Mrot = np.array([[coss, seno, 0, 0],
                         [-seno, coss, 0, 0],
                         [0, 0, coss, seno],
                         [0, 0, -seno, coss]])

        Klr = np.dot(np.dot(Mrot.T, Kl), Mrot)

        K[gl1 - 1:gl2, gl1 - 1:gl2] += Klr[0:2, 0:2]
        K[gl3 - 1:gl4, gl1 - 1:gl2] += Klr[2:4, 0:2]
        K[gl1 - 1:gl2, gl3 - 1:gl4] += Klr[0:2, 2:4]
        K[gl3 - 1:gl4, gl3 - 1:gl4] += Klr[2:4, 2:4]

    Kr = np.copy(K)

    for apoio in apoios:
        ponto = apoio[0]
        tipo = apoio[1]
        gl1 = 2 * ponto - 1
        gl2 = 2 * ponto

        if tipo == 'Fixo x':
            Kr[:, gl1 - 1] = 0
            Kr[gl1 - 1, :] = 0
            Kr[gl1 - 1, gl1 - 1] = 1
        elif tipo == 'Fixo y':
            Kr[:, gl2 - 1] = 0
            Kr[gl2 - 1, :] = 0
            Kr[gl2 - 1, gl2 - 1] = 1
        elif tipo == 'Fixo':
            Kr[:, gl1 - 1] = 0
            Kr[gl1 - 1, :] = 0
            Kr[gl1 - 1, gl1 - 1] = 1
            Kr[:, gl2 - 1] = 0
            Kr[gl2 - 1, :] = 0
            Kr[gl2 - 1, gl2 - 1] = 1

    F = np.zeros(num_graus_liberdade)

    for forca in forcas:
        ponto = forca[0]
        intensidade = forca[1]
        eixo = forca[2]
        sentido = forca[3]
        gl1 = 2 * ponto - 1
        gl2 = 2 * ponto

        if eixo == 'x':
            if sentido == 'positivo':
                F[gl1 - 1] = intensidade
            elif sentido == 'negativo':
                F[gl1 - 1] = -intensidade
        elif eixo == 'y':
            if sentido == 'positivo':
                F[gl2 - 1] = intensidade
            elif sentido == 'negativo':
                F[gl2 - 1] = -intensidade

    R = np.linalg.solve(Kr, F)

    # Printar as forças nos pontos
    for i, coordenada in enumerate(coordenadas):
        x, y = coordenada[:2]
        gl1 = 2 * (i + 1) - 1
        gl2 = 2 * (i + 1)
        print(f"Força no nó ({x:.1f}, {y:.1f}): Fx = {R[gl1 - 1]:.1f}N e Fy = {R[gl2 - 1]:.1f}N")

    # Printar os esforços nas barras
    for i, barra in enumerate(barras):
        n1, n2 = barra
        x1, y1 = coordenadas[n1 - 1][:2]
        x2, y2 = coordenadas[n2 - 1][:2]
        LX = x2 - x1
        LY = y2 - y1
        L = np.sqrt(LX ** 2 + LY ** 2)
        seno = LY / L
        coss = LX / L
        gl1 = 2 * n1 - 1
        gl2 = 2 * n1
        gl3 = 2 * n2 - 1
        gl4 = 2 * n2
        Fx1 = R[gl1 - 1]
        Fy1 = R[gl2 - 1]
        Fx2 = R[gl3 - 1]
        Fy2 = R[gl4 - 1]
        F_axial = (Fx2 - Fx1) * coss + (Fy2 - Fy1) * seno
        print(f"Força na treliça {i+1}: {F_axial:.1f}N")

    # Plotar os esforços nas barras
    plt.figure(5, figsize=(12, 3))
    plt.title('Esforços axiais em kN')

    for i, barra in enumerate(barras):
        n1, n2 = barra
        x1, y1 = coordenadas[n1 - 1][:2]
        x2, y2 = coordenadas[n2 - 1][:2]
        LX = x2 - x1
        LY = y2 - y1
        L = np.sqrt(LX ** 2 + LY ** 2)
        seno = LY / L
        coss = LX / L
        gl1 = 2 * n1 - 1
        gl2 = 2 * n1
        gl3 = 2 * n2 - 1
        gl4 = 2 * n2
        Fx1 = R[gl1 - 1]
        Fy1 = R[gl2 - 1]
        Fx2 = R[gl3 - 1]
        Fy2 = R[gl4 - 1]
        F_axial = (Fx2 - Fx1) * coss + (Fy2 - Fy1) * seno

        x = [x1, x2]
        y = [y1, y2]

        if F_axial == 0:
            cor = 'k'
        elif F_axial > 0:
            cor = 'r'
        else:
            cor = 'b'

        plt.plot(x, y, cor, zorder=-1)

        ang = np.arctan(seno / coss)
        ang = np.degrees(ang) if coss != 0 else 90

        plt.text(np.mean(x), np.mean(y),
                 '{:.2f}kN'.format(F_axial / 1000),
                 rotation=ang,
                 horizontalalignment='center',
                 verticalalignment='center',
                 size=14,
                 weight='bold')

    # Desenhando rótulas
    for ponto in coordenadas:
        x, y = ponto[:2]
        plt.scatter(x, y, s=40, color='black', marker="o", zorder=0)

    plt.show()

    # Atualizar o gráfico
    atualizar_grafico()




# Criação da janela principal
window = tk.Tk()
window.title("Diagrama de Treliças")
window.geometry("800x600")

# Criação do notebook
notebook = ttk.Notebook(window)
notebook.pack(fill=tk.BOTH, expand=True)

# Criação das abas
tab1 = ttk.Frame(notebook)
tab2 = ttk.Frame(notebook)
tab3 = ttk.Frame(notebook)
tab4 = ttk.Frame(notebook)
tab5 = ttk.Frame(notebook)

notebook.add(tab1, text="Coordenadas")
notebook.add(tab2, text="Barras")
notebook.add(tab3, text="Apoios")
notebook.add(tab4, text="Forças")
notebook.add(tab5, text="Cálculos")

# Criação do gráfico
fig = plt.figure(figsize=(6, 6), dpi=100)
ax = fig.add_subplot(111)
canvas = FigureCanvasTkAgg(fig, master=window)
canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

# Função para atualizar o gráfico
def atualizar_grafico():
    plt.clf()  # Limpar o gráfico

    # Plotar os pontos
    pontos_x = [coord[0] for coord in coordenadas]
    pontos_y = [coord[1] for coord in coordenadas]
    numeros = [coord[2] for coord in coordenadas]

    for x, y, num in zip(pontos_x, pontos_y, numeros):
        plt.text(x, y, str(num), color='blue', fontsize=12, ha='center', va='center')

    plt.plot(pontos_x, pontos_y, 'ro')

    # Plotar as barras
    for barra in barras:
        ponto1 = coordenadas[barra[0] - 1]
        ponto2 = coordenadas[barra[1] - 1]
        plt.plot([ponto1[0], ponto2[0]], [ponto1[1], ponto2[1]], 'b-')

    # Plotar os apoios
    for apoio in apoios:
        ponto = coordenadas[apoio[0] - 1]
        tipo = apoio[1]
        if tipo == 'Fixo x':
            plt.plot([ponto[0], ponto[0]], [ponto[1] - 0.5, ponto[1] + 0.5], 'g-')
            plt.plot(ponto[0], ponto[1], 'g^')
        elif tipo == 'Fixo y':
            plt.plot([ponto[0] - 0.5, ponto[0] + 0.5], [ponto[1], ponto[1]], 'g-')
            plt.plot(ponto[0], ponto[1], 'g^')
        elif tipo == 'Fixo':
            plt.plot([ponto[0] - 0.5, ponto[0] + 0.5], [ponto[1] - 0.5, ponto[1] + 0.5], 'g-')
            plt.plot(ponto[0], ponto[1], 'g^')

    # Plotar as forças
    for forca in forcas:
        ponto = coordenadas[forca[0] - 1]
        intensidade = forca[1]
        eixo = forca[2]
        sentido = forca[3]
        if eixo == 'x':
            if sentido == 'positivo':
                plt.arrow(ponto[0], ponto[1], 0.5, 0, head_width=0.2, head_length=0.3, fc='r', ec='r')
            elif sentido == 'negativo':
                plt.arrow(ponto[0], ponto[1], -0.5, 0, head_width=0.2, head_length=0.3, fc='r', ec='r')
        elif eixo == 'y':
            if sentido == 'positivo':
                plt.arrow(ponto[0], ponto[1], 0, 0.5, head_width=0.2, head_length=0.3, fc='r', ec='r')
            elif sentido == 'negativo':
                plt.arrow(ponto[0], ponto[1], 0, -0.5, head_width=0.2, head_length=0.3, fc='r', ec='r')

    canvas.draw()

# Criação dos widgets da aba "Coordenadas"
label_x = tk.Label(tab1, text="Coordenada X:")
label_x.pack()
entry_x = tk.Entry(tab1)
entry_x.pack()

label_y = tk.Label(tab1, text="Coordenada Y:")
label_y.pack()
entry_y = tk.Entry(tab1)
entry_y.pack()

btn_adicionar_ponto = tk.Button(tab1, text="Adicionar Ponto", command=adicionar_ponto)
btn_adicionar_ponto.pack()

# Criação dos widgets da aba "Barras"
label_ponto1 = tk.Label(tab2, text="Ponto 1:")
label_ponto1.pack()
entry_ponto1 = tk.Entry(tab2)
entry_ponto1.pack()

label_ponto2 = tk.Label(tab2, text="Ponto 2:")
label_ponto2.pack()
entry_ponto2 = tk.Entry(tab2)
entry_ponto2.pack()

btn_adicionar_barra = tk.Button(tab2, text="Adicionar Barra", command=adicionar_barra)
btn_adicionar_barra.pack()

# Criação dos widgets da aba "Apoios"
label_apoio = tk.Label(tab3, text="Ponto:")
label_apoio.pack()
entry_apoio = tk.Entry(tab3)
entry_apoio.pack()

label_tipo_apoio = tk.Label(tab3, text="Tipo de Apoio:")
label_tipo_apoio.pack()
combo_tipo_apoio = ttk.Combobox(tab3, values=["Fixo x", "Fixo y", "Fixo"])
combo_tipo_apoio.pack()

btn_adicionar_apoio = tk.Button(tab3, text="Adicionar Apoio", command=adicionar_apoio)
btn_adicionar_apoio.pack()

# Criação dos widgets da aba "Forças"
label_forca = tk.Label(tab4, text="Ponto:")
label_forca.pack()
entry_forca = tk.Entry(tab4)
entry_forca.pack()

label_intensidade = tk.Label(tab4, text="Intensidade:")
label_intensidade.pack()
entry_intensidade = tk.Entry(tab4)
entry_intensidade.pack()

label_eixo = tk.Label(tab4, text="Eixo:")
label_eixo.pack()
combo_eixo = ttk.Combobox(tab4, values=["x", "y"])
combo_eixo.pack()

label_sentido = tk.Label(tab4, text="Sentido:")
label_sentido.pack()
combo_sentido = ttk.Combobox(tab4, values=["positivo", "negativo"])
combo_sentido.pack()

btn_adicionar_forca = tk.Button(tab4, text="Adicionar Força", command=adicionar_forca)
btn_adicionar_forca.pack()

# Criação dos widgets da aba "Cálculos"
btn_calcular_forcas = tk.Button(tab5, text="Calcular Forças", command=calcular_forcas)
btn_calcular_forcas.pack()

# Configurar a atualização do gráfico em todas as abas
tab1.bind("<FocusIn>", lambda e: atualizar_grafico())
tab2.bind("<FocusIn>", lambda e: atualizar_grafico())
tab3.bind("<FocusIn>", lambda e: atualizar_grafico())
tab4.bind("<FocusIn>", lambda e: atualizar_grafico())
tab5.bind("<FocusIn>", lambda e: atualizar_grafico())

# Atualizar o gráfico inicialmente
atualizar_grafico()

# Executar a janela principal
window.mainloop()
